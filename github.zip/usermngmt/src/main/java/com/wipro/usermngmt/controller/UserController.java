package com.wipro.usermngmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.usermngmt.dto.ApiResponse;
import com.wipro.usermngmt.dto.UserLoginDto;
import com.wipro.usermngmt.dto.UserLogoutDto;
import com.wipro.usermngmt.entity.User;
import com.wipro.usermngmt.exception.DuplicateUserException;
import com.wipro.usermngmt.exception.UserNotFoundException;
import com.wipro.usermngmt.service.UserService;

/*
@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired 
    private UserService userService;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        return new ResponseEntity<>(userService.createUser(user), HttpStatus.CREATED);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<User> getUser(@PathVariable String userId) {
        return ResponseEntity.ok(userService.getUserByUserId(userId));
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PutMapping("/{userId}")
    public ResponseEntity<User> updateUser(@PathVariable String userId, @RequestBody User user) {
        return ResponseEntity.ok(userService.updateUser(userId, user));
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable String userId) {
        userService.deleteUser(userId);
        return ResponseEntity.ok("User deleted");
    }
    
    @GetMapping("/healthCheck")
    public ResponseEntity<String> healthChaeck() {
        return ResponseEntity.ok("ok");
    }
}
*/

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<ApiResponse> createUser(@RequestBody User user) throws DuplicateUserException {
    	ApiResponse response = new ApiResponse(userService.createUser(user), "User created succesfully", true);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateUser(@RequestBody User user) throws UserNotFoundException {
    	ApiResponse response = new ApiResponse(userService.updateUser(user), "User updated succesfully", true);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping
    public ResponseEntity<ApiResponse> deleteUser(@RequestParam int id) throws UserNotFoundException {
        userService.deleteUser(id);
        ApiResponse response = new ApiResponse(null, "User deleted succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllUsers() {
    	ApiResponse response = new ApiResponse(userService.getAllUsers(), "User list fetched succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getUser(@PathVariable int id) throws UserNotFoundException {
    	ApiResponse response = new ApiResponse(userService.getUserById(id), "User fetched succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/menu/{id}")
    public ResponseEntity<ApiResponse> getMenu(@PathVariable int id) throws UserNotFoundException{
    	ApiResponse response = new ApiResponse(userService.getMenuForUser(id), "User menu fetched succesfully", true);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@RequestBody UserLoginDto userLoginDto) throws UserNotFoundException {
    	ApiResponse response = new ApiResponse(userService.login(userLoginDto.getUserId(), userLoginDto.getPassword()), "User logged in succesfully", true);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse> logout(@RequestBody UserLogoutDto userLogoutDto) {
    	ApiResponse response = new ApiResponse(userService.logout(userLogoutDto.getUserId()), "User logged out succesfully", true);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/health")
    public ResponseEntity<ApiResponse> health() {
    	ApiResponse response = new ApiResponse("Maze hai bete", "User service is doing fine!", true);
        return ResponseEntity.ok(response);
    }
}
