package com.wipro.usermngmt.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.usermngmt.entity.User;
import com.wipro.usermngmt.exception.DuplicateUserException;
import com.wipro.usermngmt.exception.UserNotFoundException;
import com.wipro.usermngmt.repo.UserRepository;
import com.wipro.usermngmt.service.UserService;

/*
@Service
public class UserServiceImpl implements UserService {
    @Autowired private UserRepository userRepository;

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User getUserByUserId(String userId) {
        return userRepository.findByUserId(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User updateUser(String userId, User user) {
        User existing = getUserByUserId(userId);
        existing.setFirstName(user.getFirstName());
        existing.setLastName(user.getLastName());
        existing.setEmailid(user.getEmailid());
        existing.setPassword(user.getPassword());
        return userRepository.save(existing);
    }

    @Override
    public void deleteUser(String userId) {
        User user = getUserByUserId(userId);
        userRepository.delete(user);
    }
}
*/

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Override
    public User createUser(User user) throws DuplicateUserException {
    	Optional<User> existingUser = userRepository.findByUserId(user.getUserId());
    	if(existingUser.isPresent()) {
    		throw new DuplicateUserException("UserId already exists");
    	}
    	return userRepository.save(user);
    }

    @Override
    public User updateUser(User user) throws UserNotFoundException {
    	Optional<User> existingUser = userRepository.findByUserId(user.getUserId());
    	if(existingUser.isEmpty()) {
    		throw new UserNotFoundException("UserId does not exist");
    	}
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(int id) throws UserNotFoundException {
    	Optional<User> existingUser = userRepository.findById(id);
    	if(existingUser.isEmpty()) {
    		throw new UserNotFoundException("UserId does not exist");
    	}
        userRepository.deleteById(id);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(int id) throws UserNotFoundException {
        return userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    @Override
    public User login(String userId, String password) throws UserNotFoundException{
        Optional<User> userOpt = userRepository.findByUserId(userId);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            return userOpt.get();
        }
        throw new UserNotFoundException("user not found");
    }

    @Override
    public String logout(String userId) {
        return "Logout successful for user: " + userId;
    }

    @Override
    public String getMenuForUser(int id) throws UserNotFoundException {
        User user = getUserById(id);
        return user.getRoleId() == 0 ? "Admin Menu" : "Customer Menu";
    }
}
