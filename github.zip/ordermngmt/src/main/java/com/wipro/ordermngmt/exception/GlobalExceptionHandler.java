package com.wipro.ordermngmt.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.wipro.ordermngmt.dto.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(ProductNotFoundException.class)
	ResponseEntity<ApiResponse> productNotFoundExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	
	@ExceptionHandler(OrderNotFoundException.class)
	ResponseEntity<ApiResponse> orderNotFoundExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	
	@ExceptionHandler(DuplicateOrderException.class)
	ResponseEntity<ApiResponse> duplicateUserExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage());
		return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}
	
	@ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleRuntime(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }
}
