package com.wipro.ordermngmt.service;

import java.util.List;

import com.wipro.ordermngmt.entity.Cart;
import com.wipro.ordermngmt.entity.CartItem;

/*
public interface CartService {
    Cart getCartByUserId(String userId);
    Cart addItemToCart(String userId, int productId, int quantity);
    Cart removeItemFromCart(String userId, int productId);
    void clearCart(String userId);
}
*/

public interface CartService {
    CartItem addToCart(CartItem item);
    void deleteCartItem(int itemId);
    CartItem updateCartItem(CartItem item);
    List<CartItem> getUserCart(String userId);
    void clearCart(String userId);
}
