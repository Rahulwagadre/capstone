package com.wipro.ordermngmt.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.wipro.ordermngmt.dto.ProductDto;
import com.wipro.ordermngmt.entity.Cart;
import com.wipro.ordermngmt.entity.CartItem;
import com.wipro.ordermngmt.entity.Order;
import com.wipro.ordermngmt.entity.OrderItem;
import com.wipro.ordermngmt.repo.CartItemRepository;
import com.wipro.ordermngmt.repo.OrderItemRepository;
import com.wipro.ordermngmt.repo.OrderRepository;
import com.wipro.ordermngmt.service.CartService;
import com.wipro.ordermngmt.service.OrderService;

/*
@Service
public class OrderServiceImpl implements OrderService {
    @Autowired private OrderRepository orderRepository;
    @Autowired private CartService cartService;
    @Autowired private RestTemplate restTemplate;

    private final String PRODUCT_SERVICE_URL = "http://localhost:8082/products";

    @Override
    public Order placeOrderFromCart(String userId) {
        Cart cart = cartService.getCartByUserId(userId);
        Map<Integer, Integer> prodDetails = cart.getItems();

        double totalPrice = 0.0;
        int totalQty = 0;

        for (Map.Entry<Integer, Integer> entry : prodDetails.entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();

            ProductDto product = restTemplate.getForObject(PRODUCT_SERVICE_URL + "/" + productId, ProductDto.class);
            if (product == null || product.getAvailableQty() < quantity)
                throw new RuntimeException("Insufficient stock");

            totalPrice += product.getPrice() * quantity;
            totalQty += quantity;

            restTemplate.put(PRODUCT_SERVICE_URL + "/" + productId + "/decrease?qty=" + quantity, null);
        }

        Order order = new Order();
        order.setUserId(userId);
        order.setProdDetails(prodDetails);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("PLACED");
        order.setTotalPrice(totalPrice);
        order.setTotalQty(totalQty);

        Order saved = orderRepository.save(order);
        cartService.clearCart(userId);
        return saved;
    }
}
*/

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired private OrderRepository orderRepo;
    @Autowired private OrderItemRepository orderItemRepo;
    @Autowired private CartItemRepository cartItemRepo;
    @Autowired private RestTemplate restTemplate;

    private final String PRODUCT_SERVICE_URL = "http://localhost:8082/product";

    @Override
    public Order placeOrder(String userId) {
        List<CartItem> cartItems = cartItemRepo.findByUserId(userId);
        if (cartItems.isEmpty()) throw new RuntimeException("Cart is empty");

        Order order = new Order();
        order.setUserId(userId);
        order.setStatus("PLACED");
        order.setOrderDate(LocalDateTime.now());

        int totalQty = 0;
        double totalPrice = 0.0;

        Order savedOrder = orderRepo.save(order);

        for (CartItem item : cartItems) {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderId(savedOrder.getId());
            orderItem.setProductId(item.getProductId());
            orderItem.setQuantity(item.getQuantity());
            orderItemRepo.save(orderItem);

            totalQty += item.getQuantity();

            // Fetch product and reduce quantity
            ResponseEntity<ProductDto> productResp = restTemplate.getForEntity(PRODUCT_SERVICE_URL + "/" + item.getProductId(), ProductDto.class);
            ProductDto product = productResp.getBody();
            if (product != null) {
                totalPrice += product.getPrice() * item.getQuantity();
                restTemplate.put(PRODUCT_SERVICE_URL + "/changeQty?id=" + product.getProductId() + "&qtyDelta=" + (-item.getQuantity()), null);
            }
        }

        savedOrder.setTotalQty(totalQty);
        savedOrder.setTotalPrice(totalPrice);
        orderRepo.save(savedOrder);

        cartItemRepo.deleteAll(cartItems); // Clear cart
        return savedOrder;
    }

    @Override
    public Order cancelOrder(int orderId) {
        Order order = orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus("CANCELLED");
        orderRepo.save(order);

        List<OrderItem> items = orderItemRepo.findByOrderId(orderId);
        for (OrderItem item : items) {
            restTemplate.put(PRODUCT_SERVICE_URL + "/changeQty?id=" + item.getProductId() + "&qtyDelta=" + item.getQuantity(), null);
        }

        return order;
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    @Override
    public List<Order> getOrdersByUser(String userId) {
        return orderRepo.findByUserId(userId);
    }

    @Override
    public Order getOrderDetails(int orderId) {
        return orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found"));
    }
}
