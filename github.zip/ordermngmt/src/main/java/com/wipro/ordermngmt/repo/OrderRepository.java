package com.wipro.ordermngmt.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.ordermngmt.entity.Order;

/*
public interface OrderRepository extends JpaRepository<Order, Integer> {
	
}
*/

public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByUserId(String userId);
}
