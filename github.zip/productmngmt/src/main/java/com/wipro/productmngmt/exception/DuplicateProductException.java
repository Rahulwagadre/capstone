package com.wipro.productmngmt.exception;

public class DuplicateProductException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicateProductException(String msg) {
		super(msg);
	}
}
