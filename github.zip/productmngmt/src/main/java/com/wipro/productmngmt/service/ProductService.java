package com.wipro.productmngmt.service;

import java.util.List;

import com.wipro.productmngmt.entity.Product;
import com.wipro.productmngmt.exception.DuplicateProductException;
import com.wipro.productmngmt.exception.ProductNotFoundException;

/*
public interface ProductService {
    void decreaseQty(int productId, int qty);
    void increaseQty(int productId, int qty);
    Product getProduct(int id);
    Product addProduct(Product product);
    List<Product> getAll();
}
*/

public interface ProductService {
    Product createProduct(Product product) throws DuplicateProductException;
    Product updateProduct(Product product) throws ProductNotFoundException;
    void deleteProduct(int id) throws ProductNotFoundException;
    List<Product> getAllProducts();
    Product getProductById(int id) throws ProductNotFoundException;
    void changeProductQuantity(int id, int qtyDelta) throws ProductNotFoundException;
    void restoreStockByOrderId(int orderId);
}
