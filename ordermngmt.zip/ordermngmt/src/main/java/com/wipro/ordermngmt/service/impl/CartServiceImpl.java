package com.wipro.ordermngmt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.ordermngmt.entity.Cart;
import com.wipro.ordermngmt.entity.CartItem;
import com.wipro.ordermngmt.repo.CartItemRepository;
import com.wipro.ordermngmt.repo.CartRepository;
import com.wipro.ordermngmt.service.CartService;

/*
@Service
public class CartServiceImpl implements CartService {
    @Autowired private CartRepository cartRepository;

    @Override
    public Cart getCartByUserId(String userId) {
        return cartRepository.findById(userId).orElseGet(() -> {
            Cart cart = new Cart();
            cart.setUserId(userId);
            return cartRepository.save(cart);
        });
    }

    @Override
    public Cart addItemToCart(String userId, int productId, int quantity) {
        Cart cart = getCartByUserId(userId);
        cart.getItems().put(productId, cart.getItems().getOrDefault(productId, 0) + quantity);
        return cartRepository.save(cart);
    }

    @Override
    public Cart removeItemFromCart(String userId, int productId) {
        Cart cart = getCartByUserId(userId);
        cart.getItems().remove(productId);
        return cartRepository.save(cart);
    }

    @Override
    public void clearCart(String userId) {
        Cart cart = getCartByUserId(userId);
        cart.getItems().clear();
        cartRepository.save(cart);
    }
}
*/

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartItemRepository cartItemRepo;

    @Override
    public CartItem addToCart(CartItem item) {
        return cartItemRepo.save(item);
    }

    @Override
    public void deleteCartItem(int itemId) {
        cartItemRepo.deleteById(itemId);
    }

    @Override
    public CartItem updateCartItem(CartItem item) {
        return cartItemRepo.save(item);
    }

    @Override
    public List<CartItem> getUserCart(String userId) {
        return cartItemRepo.findByUserId(userId);
    }

    @Override
    public void clearCart(String userId) {
        List<CartItem> items = cartItemRepo.findByUserId(userId);
        cartItemRepo.deleteAll(items);
    }
}
