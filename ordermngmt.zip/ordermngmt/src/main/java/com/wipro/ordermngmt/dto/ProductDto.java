package com.wipro.ordermngmt.dto;

import java.time.LocalDate;


public class ProductDto {
	private int productId;
    private String prodName;
    private String prodDesc;
    private String prodCat;
    private int availableQty;
    private double price;
    private String uom;
    private double prodRating;
    private String imageURL;
    private LocalDate dateOfManufacture;
	
    public ProductDto() {
		super();
	}

	public ProductDto(int productId, String prodName, String prodDesc, String prodCat, int availableQty, double price,
			String uom, double prodRating, String imageURL, LocalDate dateOfManufacture) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		this.prodDesc = prodDesc;
		this.prodCat = prodCat;
		this.availableQty = availableQty;
		this.price = price;
		this.uom = uom;
		this.prodRating = prodRating;
		this.imageURL = imageURL;
		this.dateOfManufacture = dateOfManufacture;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public String getProdCat() {
		return prodCat;
	}

	public void setProdCat(String prodCat) {
		this.prodCat = prodCat;
	}

	public int getAvailableQty() {
		return availableQty;
	}

	public void setAvailableQty(int availableQty) {
		this.availableQty = availableQty;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public double getProdRating() {
		return prodRating;
	}

	public void setProdRating(double prodRating) {
		this.prodRating = prodRating;
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	@Override
	public String toString() {
		return "ProductDto [productId=" + productId + ", prodName=" + prodName + ", prodDesc=" + prodDesc + ", prodCat="
				+ prodCat + ", availableQty=" + availableQty + ", price=" + price + ", uom=" + uom + ", prodRating="
				+ prodRating + ", imageURL=" + imageURL + ", dateOfManufacture=" + dateOfManufacture + "]";
	}
}
