package com.wipro.ordermngmt.entity;

import java.time.LocalDateTime;
import java.util.Map;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.Table;
import jakarta.persistence.JoinColumn;

/*
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String userId;
    private Double totalPrice;
    private Integer totalQty;
    private String status;
    private LocalDateTime orderDate;

    @ElementCollection
    @CollectionTable(name = "order_items", joinColumns = @JoinColumn(name = "order_id"))
    @MapKeyColumn(name = "product_id")
    @Column(name = "quantity")
    private Map<Integer, Integer> prodDetails;

	public Order(Integer id, String userId, Double totalPrice, Integer totalQty, String status, LocalDateTime orderDate,
			Map<Integer, Integer> prodDetails) {
		super();
		this.id = id;
		this.userId = userId;
		this.totalPrice = totalPrice;
		this.totalQty = totalQty;
		this.status = status;
		this.orderDate = orderDate;
		this.prodDetails = prodDetails;
	}

	public Order() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Integer getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Integer totalQty) {
		this.totalQty = totalQty;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public Map<Integer, Integer> getProdDetails() {
		return prodDetails;
	}

	public void setProdDetails(Map<Integer, Integer> prodDetails) {
		this.prodDetails = prodDetails;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", userId=" + userId + ", totalPrice=" + totalPrice + ", totalQty=" + totalQty
				+ ", status=" + status + ", orderDate=" + orderDate + ", prodDetails=" + prodDetails + "]";
	}
}
*/

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String userId;
    private double totalPrice;
    private int totalQty;
    private String status; // e.g., "PLACED", "CANCELLED"
    private LocalDateTime orderDate;

    @ElementCollection
    @CollectionTable(name = "order_product_qty", joinColumns = @JoinColumn(name = "order_id"))
    @MapKeyColumn(name = "product_id")
    @Column(name = "quantity")
    private Map<Integer, Integer> prodDetails;

	public Order() {
		super();
	}

	public Order(int id, String userId, double totalPrice, int totalQty, String status, LocalDateTime orderDate,
			Map<Integer, Integer> prodDetails) {
		super();
		this.id = id;
		this.userId = userId;
		this.totalPrice = totalPrice;
		this.totalQty = totalQty;
		this.status = status;
		this.orderDate = orderDate;
		this.prodDetails = prodDetails;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(int totalQty) {
		this.totalQty = totalQty;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public Map<Integer, Integer> getProdDetails() {
		return prodDetails;
	}

	public void setProdDetails(Map<Integer, Integer> prodDetails) {
		this.prodDetails = prodDetails;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", userId=" + userId + ", totalPrice=" + totalPrice + ", totalQty=" + totalQty
				+ ", status=" + status + ", orderDate=" + orderDate + ", prodDetails=" + prodDetails + "]";
	}
}