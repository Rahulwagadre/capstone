package com.wipro.ordermngmt.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.ordermngmt.entity.Cart;

public interface CartRepository extends JpaRepository<Cart, String> {
	
}
