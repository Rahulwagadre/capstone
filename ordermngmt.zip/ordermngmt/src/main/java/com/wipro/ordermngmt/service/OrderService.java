package com.wipro.ordermngmt.service;

import java.util.List;

import com.wipro.ordermngmt.entity.Order;

/*
public interface OrderService {
    Order placeOrderFromCart(String userId);
}
*/

public interface OrderService {
    Order placeOrder(String userId);
    Order cancelOrder(int orderId);
    List<Order> getAllOrders();
    List<Order> getOrdersByUser(String userId);
    Order getOrderDetails(int orderId);
}
