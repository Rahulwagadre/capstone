package com.wipro.ordermngmt.exception;

public class DuplicateOrderException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicateOrderException(String msg) {
		super(msg);
	}
}
