package com.wipro.ordermngmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.ordermngmt.entity.Cart;
import com.wipro.ordermngmt.entity.CartItem;
import com.wipro.ordermngmt.service.CartService;

/*
@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired private CartService cartService;

    @GetMapping("/{userId}")
    public ResponseEntity<Cart> getCart(@PathVariable String userId) {
        return ResponseEntity.ok(cartService.getCartByUserId(userId));
    }

    @PostMapping("/{userId}/add")
    public ResponseEntity<Cart> add(@PathVariable String userId, @RequestParam int productId, @RequestParam int qty) {
        return ResponseEntity.ok(cartService.addItemToCart(userId, productId, qty));
    }

    @DeleteMapping("/{userId}/remove")
    public ResponseEntity<Cart> remove(@PathVariable String userId, @RequestParam int productId) {
        return ResponseEntity.ok(cartService.removeItemFromCart(userId, productId));
    }
    
    @GetMapping("/healthCheck")
    public ResponseEntity<String> healthChaeck() {
        return ResponseEntity.ok("ok");
    }
}
*/

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/addProd")
    public ResponseEntity<CartItem> addToCart(@RequestBody CartItem item) {
        return new ResponseEntity<>(cartService.addToCart(item), HttpStatus.CREATED);
    }

    @DeleteMapping("/deleteProd/{itemId}")
    public ResponseEntity<String> deleteCartItem(@PathVariable int itemId) {
        cartService.deleteCartItem(itemId);
        return ResponseEntity.ok("Cart item deleted");
    }

    @PutMapping("/update")
    public ResponseEntity<CartItem> updateCartItem(@RequestBody CartItem item) {
        return ResponseEntity.ok(cartService.updateCartItem(item));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<CartItem>> getUserCart(@PathVariable String userId) {
        return ResponseEntity.ok(cartService.getUserCart(userId));
    }
}
