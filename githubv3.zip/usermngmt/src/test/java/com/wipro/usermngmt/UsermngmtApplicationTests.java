package com.wipro.usermngmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermngmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
