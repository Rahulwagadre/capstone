package com.wipro.usermngmt.service;

import java.util.List;


import com.wipro.usermngmt.dto.ApiResponse;
import com.wipro.usermngmt.entity.User;
import com.wipro.usermngmt.exception.DuplicateUserException;
import com.wipro.usermngmt.exception.UserNotFoundException;

public interface UserService {
    User createUser(User user) throws DuplicateUserException;
    User updateUser(User user) throws UserNotFoundException;
    void deleteUser(int id) throws UserNotFoundException;
    List<User> getAllUsers();
    User getUserById(int id) throws UserNotFoundException;
    ApiResponse login(String userId, String password) throws UserNotFoundException;
    String logout(String userId);
    String getMenuForUser(int id) throws UserNotFoundException;
}
