package com.wipro.usermngmt.config;

import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {

	public static String secretKey = "IeTM70X8O59miRHKvUzsq0E6a6B29z9IPG5TGf96GSUIeTM70X8O59miRHKvUzsq0E6a6B29z9IPG5TGf96GSUIeTM70X8O59miRHKvUzsq0E6a6B29z9IPG5TGf96GSU";

    private static final long DEFAULT_EXPIRATION_TIME = 1000 * 60 * 60; // 1 hour expiration

    // Make the method static
    public static String generateToken(String userId, String secretKey, long expirationTime) {
        if (expirationTime == 0) expirationTime = DEFAULT_EXPIRATION_TIME;

        return Jwts.builder()
                .setSubject(userId)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SignatureAlgorithm.HS512, secretKey.getBytes())
                .compact();
    }
    
    /*
    public static String generateTokenV1(String userId, String role, String secretKey, long expirationTime) {
        if (expirationTime == 0) expirationTime = DEFAULT_EXPIRATION_TIME;

        return Jwts.builder()
                .setSubject(userId)
                .claim("role", role) // Add role claim
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SignatureAlgorithm.HS512, secretKey.getBytes())
                .compact();
    }
    
    // method to extract role from token
    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class));
    }
	*/
    // Generate a token with the default expiration time
    public static String generateToken(String userId, String secretKey) {
        return generateToken(userId, secretKey, 0);
    }

    public String extractUserId(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    private <T> T extractClaim(String token, ClaimsResolver<T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.resolve(claims);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(secretKey.getBytes())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public boolean validateToken(String token, String userId) {
        return (userId.equals(extractUserId(token)) && !isTokenExpired(token));
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    @FunctionalInterface
    private interface ClaimsResolver<T> {
        T resolve(Claims claims);
    }
}
