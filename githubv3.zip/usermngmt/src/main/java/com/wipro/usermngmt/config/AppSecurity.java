package com.wipro.usermngmt.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class AppSecurity {

    @Autowired
    private JwtUtil jwtUtil;  // Inject JwtUtil here

    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        return new JwtAuthenticationFilter(jwtUtil);  // Pass JwtUtil to the filter
    }

    /*
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())  // Disable CSRF protection
            .addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)  // Add the custom filter before default filter
            .authorizeHttpRequests(authorizeRequests ->
                authorizeRequests
//                     .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                    .requestMatchers("/user/login/**", "/user/register/**").permitAll()  // Public access to login/register
                    .anyRequest().authenticated()  // Secure other requests
            );

        return http.build();
    }
    */
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
            .addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authorizeRequests ->
                authorizeRequests
                    .requestMatchers("/user/login/**", "/user/register/**", "/user/health").permitAll()
                    .requestMatchers("/user/admin/**").hasRole("ADMIN") // Admin-only endpoints
                    .requestMatchers("/user/customer/**").hasRole("CUSTOMER") // Customer-only endpoints
                    .anyRequest().authenticated()
            );

        return http.build();
    }
}