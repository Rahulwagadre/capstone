package com.wipro.usermngmt.dto;

public class UserLogoutDto {
	private String userId;

	public UserLogoutDto(String userId) {
		super();
		this.userId = userId;
	}

	public UserLogoutDto() {

	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
