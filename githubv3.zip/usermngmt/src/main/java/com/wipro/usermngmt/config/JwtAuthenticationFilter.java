package com.wipro.usermngmt.config;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    public JwtAuthenticationFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        try {
            String token = extractTokenFromHeader(request);

            if (token != null && jwtUtil.validateToken(token, extractUserIdFromToken(token))) {
                setUpSpringAuthentication(token);
            } else {
                logger.warn("Invalid or expired JWT token");
            }
            filterChain.doFilter(request, response);
        } catch (ExpiredJwtException e) {
            handleJwtException(response, "JWT token is expired", HttpServletResponse.SC_UNAUTHORIZED, e);
        } catch (UnsupportedJwtException | MalformedJwtException e) {
            handleJwtException(response, "Invalid JWT token", HttpServletResponse.SC_UNAUTHORIZED, e);
        } catch (Exception e) {
            handleJwtException(response, "Error processing JWT token", HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e);
        }
    }

    private void handleJwtException(HttpServletResponse response, String message, int status, Exception e) throws IOException {
        response.setStatus(status);
        response.sendError(status, message);
        logger.error(message, e);
    }

    private String extractTokenFromHeader(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        return (header != null && header.startsWith("Bearer ")) ? header.substring(7) : null;
    }

    private String extractUserIdFromToken(String token) {
        return jwtUtil.extractUserId(token);
    }


    private void setUpSpringAuthentication(String token) {
        String userId = extractUserIdFromToken(token);
        List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("USER"));
        //List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_USER")); // Example role, adjust accordingly
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userId, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }
 /* 
 // In JwtAuthenticationFilter.java
    private void setUpSpringAuthentication(String token) {
        String userId = extractUserIdFromToken(token);
        String role = jwtUtil.extractRole(token); // Extract role from token
        
        // Create authority based on role
        List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(role));
        UsernamePasswordAuthenticationToken authentication = 
            new UsernamePasswordAuthenticationToken(userId, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }
      */
}