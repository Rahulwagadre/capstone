package com.wipro.usermngmt.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.wipro.usermngmt.config.JwtUtil;
import com.wipro.usermngmt.dto.ApiResponse;
import com.wipro.usermngmt.entity.User;
import com.wipro.usermngmt.exception.DuplicateUserException;
import com.wipro.usermngmt.exception.UserNotFoundException;
import com.wipro.usermngmt.repo.UserRepository;
import com.wipro.usermngmt.service.UserService;
import com.wipro.usermngmt.util.AppConstant;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Override
    public User createUser(User user) throws DuplicateUserException {
    	Optional<User> existingUser = userRepository.findByUserId(user.getUserId());
        if(existingUser.isPresent()) {
            throw new DuplicateUserException("UserId already exists");
        }
        
        // Generate a random salt
        String salt = BCrypt.gensalt();
        user.setSalt(salt);
        
        // Hash the password with the generated salt
        String hashedPassword = BCrypt.hashpw(user.getPassword(), salt);
        user.setPassword(hashedPassword);
        
        // Set default role if not provided
        if(user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("ROLE_USER"); // or whatever your default role should be
        }
        
        return userRepository.save(user);

    }

    @Override
    public User updateUser(User user) throws UserNotFoundException {
    	Optional<User> existingUser = userRepository.findByUserId(user.getUserId());
    	if(existingUser.isEmpty()) {
    		throw new UserNotFoundException("UserId does not exist");
    	}
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(int id) throws UserNotFoundException {
    	Optional<User> existingUser = userRepository.findById(id);
    	if(existingUser.isEmpty()) {
    		throw new UserNotFoundException("UserId does not exist");
    	}
        userRepository.deleteById(id);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(int id) throws UserNotFoundException {
        return userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    /*
    @Override
    public User login(String userId, String password) throws UserNotFoundException{
        Optional<User> userOpt = userRepository.findByUserId(userId);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            return userOpt.get();
        }
        throw new UserNotFoundException("user not found");
    }
    */

    @Override
    public String logout(String userId) {
        return "Logout successful for user: " + userId;
    }

    @Override
    public String getMenuForUser(int id) throws UserNotFoundException {
        User user = getUserById(id);
        return user.getRole();
    }
    
    @Override
    public ApiResponse login(String userName, String password) {
    	Optional<User> userOpt = userRepository.findByUserId(userName);
        
        if (userOpt.isPresent()) {
        	User user = userOpt.get();
            String salt = user.getSalt();
            String hashedPassword = BCrypt.hashpw(password, salt);

            if (hashedPassword.equals(user.getPassword())) {
            	String token = JwtUtil.generateToken(user.getUserId(), JwtUtil.secretKey);
				//String token2 = JwtUtil.generateTokenV1(user.getUserId(), user.getRole(), JwtUtil.secretKey, AppConstant.JWT_EXPIRATION_TIME);
                ApiResponse response = new ApiResponse(user, token, true);
                return response;
            }
        }

        throw new RuntimeException("Invalid credentials");
    }
}
