package com.wipro.usermngmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.usermngmt.dto.ApiResponse;
import com.wipro.usermngmt.dto.UserLoginDto;
import com.wipro.usermngmt.dto.UserLogoutDto;
import com.wipro.usermngmt.entity.User;
import com.wipro.usermngmt.exception.DuplicateUserException;
import com.wipro.usermngmt.exception.UserNotFoundException;
import com.wipro.usermngmt.service.UserService;


@CrossOrigin("*")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse> createUser(@RequestBody User user) throws DuplicateUserException {
    	ApiResponse response = new ApiResponse(userService.createUser(user), "User created succesfully", true);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateUser(@RequestBody User user) throws UserNotFoundException {
    	ApiResponse response = new ApiResponse(userService.updateUser(user), "User updated succesfully", true);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping
    public ResponseEntity<ApiResponse> deleteUser(@RequestParam int id) throws UserNotFoundException {
        userService.deleteUser(id);
        ApiResponse response = new ApiResponse(null, "User deleted succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllUsers() {
    	ApiResponse response = new ApiResponse(userService.getAllUsers(), "User list fetched succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getUser(@PathVariable int id) throws UserNotFoundException {
    	ApiResponse response = new ApiResponse(userService.getUserById(id), "User fetched succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/menu/{id}")
    public ResponseEntity<ApiResponse> getMenu(@PathVariable int id) throws UserNotFoundException{
    	ApiResponse response = new ApiResponse(userService.getMenuForUser(id), "User menu fetched succesfully", true);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@RequestBody UserLoginDto userLoginDto) throws UserNotFoundException {
//    	ApiResponse response = new ApiResponse(userService.login(userLoginDto.getUserId(), userLoginDto.getPassword()), "User logged in succesfully", true);
//        return ResponseEntity.ok(response);
        return ResponseEntity.ok(userService.login(userLoginDto.getUserId(), userLoginDto.getPassword()));
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse> logout(@RequestBody UserLogoutDto userLogoutDto) {
    	ApiResponse response = new ApiResponse(userService.logout(userLogoutDto.getUserId()), "User logged out succesfully", true);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/health")
    public ResponseEntity<ApiResponse> health() {
    	ApiResponse response = new ApiResponse("Maze hai bete", "User service is doing fine!", true);
        return ResponseEntity.ok(response);
    }
}

/*
@CrossOrigin("*")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    // Public endpoints
    @PostMapping("/register")
    public ResponseEntity<ApiResponse> createUser(@RequestBody User user) throws DuplicateUserException {
        ApiResponse response = new ApiResponse(userService.createUser(user), "User created successfully", true);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Admin-only endpoints
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/all")
    public ResponseEntity<ApiResponse> getAllUsers() {
        ApiResponse response = new ApiResponse(userService.getAllUsers(), "User list fetched successfully", true);
        return ResponseEntity.ok(response);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/admin/{id}")
    public ResponseEntity<ApiResponse> deleteUser(@PathVariable int id) throws UserNotFoundException {
        userService.deleteUser(id);
        ApiResponse response = new ApiResponse(null, "User deleted successfully", true);
        return ResponseEntity.ok(response);
    }

    // Customer-only endpoints
    @PreAuthorize("hasRole('CUSTOMER')")
    @GetMapping("/customer/{id}")
    public ResponseEntity<ApiResponse> getCustomerProfile(@PathVariable int id) throws UserNotFoundException {
        ApiResponse response = new ApiResponse(userService.getUserById(id), "Profile fetched successfully", true);
        return ResponseEntity.ok(response);
    }

    // Shared endpoints (both admin and customer)
    @PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')")
    @PutMapping
    public ResponseEntity<ApiResponse> updateUser(@RequestBody User user) throws UserNotFoundException {
        ApiResponse response = new ApiResponse(userService.updateUser(user), "User updated successfully", true);
        return ResponseEntity.ok(response);
    }

    // Public endpoints
    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@RequestBody UserLoginDto userLoginDto) throws UserNotFoundException {
        return ResponseEntity.ok(userService.login(userLoginDto.getUserId(), userLoginDto.getPassword()));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse> health() {
        ApiResponse response = new ApiResponse("Maze hai bete", "User service is doing fine!", true);
        return ResponseEntity.ok(response);
    }
}
*/