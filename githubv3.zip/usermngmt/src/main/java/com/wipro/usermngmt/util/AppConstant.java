package com.wipro.usermngmt.util;

public class AppConstant {

    // Secret key for signing JWT tokens
    public static final String SECRET_KEY = "F6QpRB7yKj9yG4zABxC3D2E1F5R6T7yH8J9iK01M1N2B3V4cD5eF6G7hT8jK91M0nP1qR28T3vB4xC5dE6fG7hI8jK91M0nP";

    // JWT Header prefix
    public static final String HEADER = "Authorization";
    public static final String PREFIX = "Bearer ";

    // JWT expiration time (in milliseconds)
    public static final long JWT_EXPIRATION_TIME = 86400000L;  // 24 hours

    // Other constants (roles, etc.)
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String ROLE_USER = "ROLE_USER";
}