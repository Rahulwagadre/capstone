package com.wipro.usermngmt.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.wipro.usermngmt.dto.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(UserNotFoundException.class)
	ResponseEntity<ApiResponse> userNotFoundExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage(), false);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	
	@ExceptionHandler(DuplicateUserException.class)
	ResponseEntity<ApiResponse> duplicateUserExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage(), false);
		return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}
	
	@ExceptionHandler(Exception.class)
	ResponseEntity<ApiResponse> genericExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage(), false);
		return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}
}
