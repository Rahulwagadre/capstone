package com.wipro.productmngmt.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.productmngmt.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	
}