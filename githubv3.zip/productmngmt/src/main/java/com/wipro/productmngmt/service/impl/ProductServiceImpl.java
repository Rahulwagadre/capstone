package com.wipro.productmngmt.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.productmngmt.entity.Product;
import com.wipro.productmngmt.exception.DuplicateProductException;
import com.wipro.productmngmt.exception.ProductNotFoundException;
import com.wipro.productmngmt.repo.ProductRepository;
import com.wipro.productmngmt.service.ProductService;


@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product createProduct(Product product) throws DuplicateProductException{
    	Optional<Product> productOpt = productRepository.findById(product.getId());
    	if(productOpt.isPresent()) {
    		throw new DuplicateProductException("Product already exists");
    	}
        return productRepository.save(product);
    }

    @Override
    public Product updateProduct(Product product) throws ProductNotFoundException{
    	Optional<Product> productOpt = productRepository.findById(product.getId());
    	if(productOpt.isEmpty()) {
    		throw new ProductNotFoundException("Product does not exist");
    	}
        return productRepository.save(product);
    }

    @Override
    public void deleteProduct(int id) throws ProductNotFoundException{
    	Optional<Product> productOpt = productRepository.findById(id);
    	if(productOpt.isEmpty()) {
    		throw new ProductNotFoundException("Product does not exist");
    	}
        productRepository.deleteById(id);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product getProductById(int id) throws ProductNotFoundException{
    	return productRepository.findById(id)
            .orElseThrow(() -> new ProductNotFoundException("Product not found"));
    }

    @Override
    public void changeProductQuantity(int id, int qtyDelta) throws ProductNotFoundException {
        Product product = getProductById(id);
        product.setQuantity(product.getQuantity() + qtyDelta);
        productRepository.save(product);
    }

    @Override
    public void restoreStockByOrderId(int orderId) {
        // Optional - actual logic is managed by OrderService via RestTemplate
    }

	@Override
	public Product updateProductQty(int productId, int qty) throws ProductNotFoundException {
		Product product = getProductById(productId);
		product.setQuantity(product.getQuantity() + qty);
		return productRepository.save(product);
	}
}
