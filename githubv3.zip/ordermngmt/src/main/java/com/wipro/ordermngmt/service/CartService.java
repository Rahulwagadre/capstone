package com.wipro.ordermngmt.service;

import com.wipro.ordermngmt.dto.CartRequestDto;
import com.wipro.ordermngmt.dto.UpdateCartDto;
import com.wipro.ordermngmt.entity.CartItem;

public interface CartService {
	CartItem addProductToCart(CartRequestDto dto);
    void deleteProductFromCart(Integer cartItemId);
    CartItem updateProductQty(UpdateCartDto dto);
    CartItem viewCart(String userId);
    CartItem deleteProduct(String userId, Integer productId);
}
