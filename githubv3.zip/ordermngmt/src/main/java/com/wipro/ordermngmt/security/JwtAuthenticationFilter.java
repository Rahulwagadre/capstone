package com.wipro.ordermngmt.security;
/*
import java.io.IOException;
import java.util.ArrayList;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
 
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
 
    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);
    private final JwtUtil jwtUtil;
 
    public JwtAuthenticationFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }
 
//    @Override
//    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//            throws ServletException, IOException {
//        
//        String token = extractTokenFromHeader(request);
//        String userId = null;
//
//        if (token != null) {
//            try {
//                // Extract userId from token using JwtUtil
//                userId = jwtUtil.extractUserId(token);
//
//                logger.debug("Extracted token: {}", token);
//                logger.debug("Extracted userId from token: {}", userId);
//            } catch (Exception e) {
//                logger.error("Error while extracting userId from token: {}", e.getMessage());
//            }
//        } else {
//            logger.warn("No JWT token found in Authorization header.");
//        }
//
//        // Validate token
//        if (userId != null && jwtUtil.validateToken(token, userId)) {
// logger.info("Token validation successful for userId: {}", userId);
//            filterChain.doFilter(request, response);  // Proceed with the request
//        } else {
//            logger.error("Token validation failed for userId: {}. Rejecting request.", userId);
//            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//            response.getWriter().write("Unauthorized access, invalid token.");
//        }
//    }
    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        String token = extractTokenFromHeader(request);  // Get token from request header
 
        if (token != null && !token.isEmpty()) {
            try {
                String userId = jwtUtil.extractUserId(token);
                
                if (jwtUtil.validateToken(token, userId)) {
                    // If the token is valid, set the authentication context
                    UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(userId, null, new ArrayList<>());
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                } else {
                    // Invalid token (expired, signature issue, etc.)
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);  // Forbidden or Unauthorized
                }
            } catch (Exception e) {
                // Handle exception (Invalid token, etc.)
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            }
        }
        chain.doFilter(request, response);  // Continue the filter chain
    }
 
    private String extractTokenFromHeader(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            return header.substring(7);  // Extract token from "Bearer <token>"
        }
        return null;
    }
}
*/