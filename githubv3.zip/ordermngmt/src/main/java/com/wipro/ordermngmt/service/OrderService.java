package com.wipro.ordermngmt.service;

import java.util.List;

import com.wipro.ordermngmt.dto.OrderRequestDto;
import com.wipro.ordermngmt.entity.Order;

public interface OrderService {
	Order createOrder(OrderRequestDto dto);
    Order cancelOrder(Integer orderId);
    List<Order> getAllOrders();
    List<Order> getOrdersByUser(String userId);
    Order getOrderById(Integer orderId);
}
