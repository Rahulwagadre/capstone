package com.wipro.ordermngmt.entity;

import java.util.HashMap;
import java.util.Map;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "cart")
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private String userId;  // Changed from Integer to String

    @ElementCollection
    @CollectionTable(name = "cart_product_qty", joinColumns = @JoinColumn(name = "cart_item_id"))
    @MapKeyColumn(name = "product_id")
    @Column(name = "quantity")
    private Map<Integer, Integer> prodDetails = new HashMap<>();

    @Column(name = "total_qty")
    private Integer totalQty;

    @Column(name = "total_price")
    private Double totalPrice;

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserId() {  // Changed from Integer to String
        return userId;
    }

    public void setUserId(String userId) {  // Changed from Integer to String
        this.userId = userId;
    }

    public Map<Integer, Integer> getProdDetails() {
        return prodDetails;
    }

    public void setProdDetails(Map<Integer, Integer> prodDetails) {
        this.prodDetails = prodDetails;
    }

    public Integer getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(Integer totalQty) {
        this.totalQty = totalQty;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
