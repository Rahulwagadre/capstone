package com.wipro.ordermngmt.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.wipro.ordermngmt.dto.ApiResponse;
import com.wipro.ordermngmt.dto.OrderRequestDto;
import com.wipro.ordermngmt.entity.CartItem;
import com.wipro.ordermngmt.entity.Order;
import com.wipro.ordermngmt.repo.CartRepository;
import com.wipro.ordermngmt.repo.OrderRepository;
import com.wipro.ordermngmt.service.OrderService;

import jakarta.transaction.Transactional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;
    
    @Autowired
	private RestTemplate restTemplate;
	
	private static final String PRODUCT_SVC_URL = "http://PRODUCTMNGMT/product/{productId}/{qty}";

    @Transactional
    @Override
    public Order createOrder(OrderRequestDto dto) {
        CartItem cart = cartRepository.findByUserId(dto.getUserId())
                                      .orElseThrow(() -> new RuntimeException("Cart not found"));

        // force initialization of the lazy map
        cart.getProdDetails().size();   // or Hibernate.initialize(cart.getProdDetails());

        Order order = new Order();
        order.setUserId(dto.getUserId());
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("PLACED");
        order.setTotalQty(cart.getTotalQty());
        order.setTotalPrice(cart.getTotalPrice());
        order.setProdDetails(new HashMap<>(cart.getProdDetails()));  // defensive copy

        Order savedOrder = orderRepository.save(order);
        
        Map<Integer, Integer> productQtyMap = new HashMap<>(cart.getProdDetails());
        for (Map.Entry<Integer, Integer> entry : productQtyMap.entrySet()) {
            int productId = entry.getKey();
            int productQty = entry.getValue() * -1;
            restTemplate.exchange(
                    PRODUCT_SVC_URL,
                    HttpMethod.PUT,
                    null, // no request body or headers
                    ApiResponse.class,
                    productId,
                    productQty
            ).getBody();
        }
        cartRepository.delete(cart);   // now safe
     
        return savedOrder;
    }

    @Override
    public Order cancelOrder(Integer orderId) {
        Order order = orderRepository.findById(orderId).orElseThrow();
        order.setStatus("CANCELLED");
        Order canceledOrder = orderRepository.save(order);
        Map<Integer, Integer> productQtyMap = new HashMap<>(canceledOrder.getProdDetails());
        for (Map.Entry<Integer, Integer> entry : productQtyMap.entrySet()) {
            int productId = entry.getKey();
            int productQty = entry.getValue();
            restTemplate.exchange(
                    PRODUCT_SVC_URL,
                    HttpMethod.PUT,
                    null, // no request body or headers
                    ApiResponse.class,
                    productId,
                    productQty
            ).getBody();
        }
        return canceledOrder;
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public List<Order> getOrdersByUser(String userId) {
        return orderRepository.findByUserId(userId);
    }

    @Override
    public Order getOrderById(Integer orderId) {
        return orderRepository.findById(orderId).orElseThrow();
    }
}