package com.wipro.ordermngmt.dto;

public class DeleteProductFromCartDto {
	private String userId;
    private Integer productId;
	public DeleteProductFromCartDto() {
		super();
	}
	public DeleteProductFromCartDto(String userId, Integer productId) {
		super();
		this.userId = userId;
		this.productId = productId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	@Override
	public String toString() {
		return "DeleteProductFromCartDto [userId=" + userId + ", productId=" + productId + "]";
	}
    
}
