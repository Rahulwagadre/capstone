package com.wipro.ordermngmt.dto;

public class OrderRequestDto {
	private String userId;

	public OrderRequestDto(String userId) {
		super();
		this.userId = userId;
	}
	
	public OrderRequestDto() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "OrderRequestDtov1 [userId=" + userId + "]";
	}

}
