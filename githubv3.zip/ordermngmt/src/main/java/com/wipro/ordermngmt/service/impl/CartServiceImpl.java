package com.wipro.ordermngmt.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.ordermngmt.dto.ApiResponse;
import com.wipro.ordermngmt.dto.CartRequestDto;
import com.wipro.ordermngmt.dto.ProductDto;
import com.wipro.ordermngmt.dto.UpdateCartDto;
import com.wipro.ordermngmt.entity.CartItem;
import com.wipro.ordermngmt.repo.CartRepository;
import com.wipro.ordermngmt.service.CartService;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	private static final String PRODUCT_SVC_URL = "http://PRODUCTMNGMT/product/{id}";

	
	@Override
    public CartItem addProductToCart(CartRequestDto dto) {

        /* 2. ─── Find or create the user's cart ────────────────────────────── */
        CartItem cart = cartRepository.findByUserId(dto.getUserId())
                                      .orElseGet(() -> {
                                          CartItem c = new CartItem();
                                          c.setUserId(dto.getUserId());
                                          c.setProdDetails(new HashMap<>());
                                          return c;
                                      });

        /* 3. ─── Merge the product line ───────────────────────────────────── */
        Map<Integer,Integer> details = cart.getProdDetails();
        details.put(dto.getProductId(),
                    details.getOrDefault(dto.getProductId(), 0) + dto.getQuantity());

        /* 4. ─── Re-calculate totals using real product prices ────────────── */
        double grandTotal = 0.0;
        int totalQty = 0;
       
        for (Map.Entry<Integer,Integer> e : details.entrySet()) {
            // fetch price for each line (you may cache or bulk-fetch in real life)
        	ApiResponse response = restTemplate.getForObject(PRODUCT_SVC_URL, ApiResponse.class, e.getKey());
    		
            if (response == null) {
                throw new RuntimeException("Product " + dto.getProductId() + " not found");
            }
            
            Object p = response.getData();
            
            if (p == null) {
                throw new RuntimeException("Product not found");
            }
            
            ProductDto product = new ObjectMapper()
                    .convertValue(p, ProductDto.class);
            
            if(product.getQuantity() < e.getValue()) {
            	throw new RuntimeException("Product " + dto.getProductId() + " is out of stock");
            }
            
            grandTotal += product.getPrice() * e.getValue();
            totalQty   += e.getValue();
        }
        cart.setTotalPrice(grandTotal);
        cart.setTotalQty(totalQty);

        /* 5. ─── Persist & return ─────────────────────────────────────────── */
        return cartRepository.save(cart);
    }
	
	/*
	@Override
	public CartItem addProductToCart(CartRequestDto dto) {
		CartItem cart = cartRepository.findByUserId(dto.getUserId()).orElse(new CartItem());
        cart.setUserId(dto.getUserId());

        Map<Integer, Integer> details = cart.getProdDetails();
        details.put(dto.getProductId(), details.getOrDefault(dto.getProductId(), 0) + dto.getQuantity());

        cart.setTotalQty(details.values().stream().mapToInt(i -> i).sum());
        cart.setTotalPrice(cart.getTotalQty() * 100.0); // assuming price 100/unit
        return cartRepository.save(cart);
	}*/

	@Override
	public void deleteProductFromCart(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
	}

	@Override
	public CartItem updateProductQty(UpdateCartDto dto) {
		CartItem cart = cartRepository.findByUserId(dto.getUserId()).orElseThrow();
        cart.getProdDetails().put(dto.getProductId(), dto.getQuantity());
        cart.setTotalQty(cart.getProdDetails().values().stream().mapToInt(i -> i).sum());
        cart.setTotalPrice(cart.getTotalQty() * 100.0);
        return cartRepository.save(cart);
	}

	@Override
	public CartItem viewCart(String userId) {
		return cartRepository.findByUserId(userId).orElseThrow();
    }
	
	@Override
	public CartItem deleteProduct(String userId, Integer productId) {
	    CartItem cart = cartRepository.findByUserId(userId)
	                                  .orElseThrow(() -> new RuntimeException("Cart not found"));

	    Map<Integer,Integer> details = cart.getProdDetails();
	    if (!details.containsKey(productId)) {
	        throw new RuntimeException("Product not in cart");
	    }

	    details.remove(productId);

	    // recalc totals
	    cart.setTotalQty(details.values().stream().mapToInt(i -> i).sum());
	    cart.setTotalPrice(cart.getTotalQty() * 100.0);   // TODO: real pricing

	    // if cart is now empty you could decide to delete it instead
	    return cartRepository.save(cart);
	}

}
