package com.wipro.ordermngmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdermngmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
