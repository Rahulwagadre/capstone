package com.wipro.usermngmt.service;

import java.util.List;

import com.wipro.usermngmt.entity.User;
import com.wipro.usermngmt.exception.DuplicateUserException;
import com.wipro.usermngmt.exception.UserNotFoundException;

/*
public interface UserService {
    User createUser(User user);
    User getUserByUserId(String userId);
    List<User> getAllUsers();
    User updateUser(String userId, User user);
    void deleteUser(String userId);
}
*/

public interface UserService {
    User createUser(User user) throws DuplicateUserException;
    User updateUser(User user) throws UserNotFoundException;
    void deleteUser(int id) throws UserNotFoundException;
    List<User> getAllUsers();
    User getUserById(int id) throws UserNotFoundException;
    User login(String userId, String password) throws UserNotFoundException;
    String logout(String userId);
    String getMenuForUser(int id) throws UserNotFoundException;
}
