package com.wipro.productmngmt.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.wipro.productmngmt.dto.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(ProductNotFoundException.class)
	ResponseEntity<ApiResponse> productNotFoundExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage(), false);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	
	@ExceptionHandler(DuplicateProductException.class)
	ResponseEntity<ApiResponse> duplicateUserExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage(), false);
		return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}
	
	@ExceptionHandler(Exception.class)
	ResponseEntity<ApiResponse> genericExceptionHandler(Exception ex) {
		ApiResponse response = new ApiResponse(null, ex.getMessage(), false);
		return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}
}
