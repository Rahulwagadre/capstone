package com.wipro.productmngmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProductmngmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductmngmtApplication.class, args);
	}

}
