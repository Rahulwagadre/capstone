package com.wipro.productmngmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.productmngmt.dto.ApiResponse;
import com.wipro.productmngmt.entity.Product;
import com.wipro.productmngmt.exception.DuplicateProductException;
import com.wipro.productmngmt.exception.ProductNotFoundException;
import com.wipro.productmngmt.service.ProductService;

/*
@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired private ProductService productService;

    @PutMapping("/{id}/decrease")
    public ResponseEntity<String> decrease(@PathVariable int id, @RequestParam int qty) {
        productService.decreaseQty(id, qty);
        return ResponseEntity.ok("Decreased");
    }

    @PutMapping("/{id}/increase")
    public ResponseEntity<String> increase(@PathVariable int id, @RequestParam int qty) {
        productService.increaseQty(id, qty);
        return ResponseEntity.ok("Increased");
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProduct(@PathVariable int id) {
        return ResponseEntity.ok(productService.getProduct(id));
    }

    @PostMapping
    public ResponseEntity<Product> addProduct(@RequestBody Product p) {
        return new ResponseEntity<>(productService.addProduct(p), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAll() {
        return ResponseEntity.ok(productService.getAll());
    }
    
    @GetMapping("/healthCheck")
    public ResponseEntity<String> healthChaeck() {
        return ResponseEntity.ok("ok");
    }
}
*/

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public ResponseEntity<ApiResponse> createProduct(@RequestBody Product product) throws DuplicateProductException{
    	ApiResponse response = new ApiResponse(productService.createProduct(product), "product created succesfully", true);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateProduct(@RequestBody Product product) throws ProductNotFoundException{
    	ApiResponse response = new ApiResponse(productService.updateProduct(product), "product updated succesfully", true);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteProduct(@PathVariable int id) throws ProductNotFoundException{
        productService.deleteProduct(id);
        ApiResponse response = new ApiResponse(null, "Product deleted succesfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllProducts() {
    	ApiResponse response = new ApiResponse(productService.getAllProducts(), "Products fetched successfully", true);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getProduct(@PathVariable int id) throws ProductNotFoundException{
    	ApiResponse response = new ApiResponse(productService.getProductById(id), "Product fetched successfully", true);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/changeQty")
    public ResponseEntity<ApiResponse> changeQty(@RequestParam int id, @RequestParam int qtyDelta) throws ProductNotFoundException{
    	ApiResponse response = new ApiResponse(null, "Quantity updated successfully", true);
        productService.changeProductQuantity(id, qtyDelta);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/restoreStockByOrderId")
    public ResponseEntity<ApiResponse> restoreStock(@RequestParam int orderId) {
    	ApiResponse response = new ApiResponse(null, "Stock restored based on orderId", true);
        productService.restoreStockByOrderId(orderId);
        return ResponseEntity.ok(response);
    }
}
