package com.wipro.productmngmt.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*
@Entity
@Table(name = "product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PROD_ID")
    private int productId;

    @Column(name = "PROD_NAME")
    private String prodName;

    @Column(name = "PROD_DESC")
    private String prodDesc;

    @Column(name = "PROD_CAT")
    private String prodCat;

    @Column(name = "PROD_QTY")
    private int availableQty;

    @Column(name = "PROD_PRICE")
    private double price;

    @Column(name = "PROD_UOM")
    private String uom;

    @Column(name = "PROD_RATING")
    private double prodRating;

    @Column(name = "PROD_IMAGEURL")
    private String imageURL;

    @Column(name = "PROD_MANUF_DATE")
    private LocalDate dateOfManufacture;

	public Product() {
		super();
	}

	public Product(int productId, String prodName, String prodDesc, String prodCat, int availableQty, double price,
			String uom, double prodRating, String imageURL, LocalDate dateOfManufacture) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		this.prodDesc = prodDesc;
		this.prodCat = prodCat;
		this.availableQty = availableQty;
		this.price = price;
		this.uom = uom;
		this.prodRating = prodRating;
		this.imageURL = imageURL;
		this.dateOfManufacture = dateOfManufacture;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public String getProdCat() {
		return prodCat;
	}

	public void setProdCat(String prodCat) {
		this.prodCat = prodCat;
	}

	public int getAvailableQty() {
		return availableQty;
	}

	public void setAvailableQty(int availableQty) {
		this.availableQty = availableQty;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public double getProdRating() {
		return prodRating;
	}

	public void setProdRating(double prodRating) {
		this.prodRating = prodRating;
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", prodName=" + prodName + ", prodDesc=" + prodDesc + ", prodCat="
				+ prodCat + ", availableQty=" + availableQty + ", price=" + price + ", uom=" + uom + ", prodRating="
				+ prodRating + ", imageURL=" + imageURL + ", dateOfManufacture=" + dateOfManufacture + "]";
	}
}
*/

@Entity
@Table(name = "product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String description;
    private double price;
    private int quantity;
    private String category;
    private String brand;
    private String imageUrl;
    private LocalDate dateOfManufacture;
	public Product() {
		super();
	}
	public Product(int id, String name, String description, double price, int quantity, String category, String brand,
			String imageUrl, LocalDate dateOfManufacture) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
		this.category = category;
		this.brand = brand;
		this.imageUrl = imageUrl;
		this.dateOfManufacture = dateOfManufacture;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public LocalDate getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(LocalDate dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", quantity=" + quantity + ", category=" + category + ", brand=" + brand + ", imageUrl=" + imageUrl
				+ ", dateOfManufacture=" + dateOfManufacture + "]";
	}
    
}
